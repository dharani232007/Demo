"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Shield, Eye, EyeOff } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface AdminLoginProps {
  onLoginSuccess?: (doctor: any) => void
}

export function AdminLogin({ onLoginSuccess }: AdminLoginProps) {
  const { toast } = useToast()
  const [adminId, setAdminId] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleLogin = async () => {
    if (!adminId || !password) {
      toast({
        title: "Missing Information",
        description: "Please enter both Admin ID and password.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // Simulate login process
    setTimeout(() => {
      // In a real app, this would validate against the backend
      const hospitalData = localStorage.getItem("hospitalData")
      if (hospitalData) {
        const data = JSON.parse(hospitalData)
        const doctor = data.doctors.find((d: any) => d.adminId === adminId && d.password === password)

        if (doctor) {
          toast({
            title: "Login Successful!",
            description: `Welcome back, Dr. ${doctor.name}`,
          })
          localStorage.setItem("currentAdmin", JSON.stringify(doctor))
          if (onLoginSuccess) {
            onLoginSuccess(doctor)
          }
        } else {
          toast({
            title: "Login Failed",
            description: "Invalid Admin ID or password. Please try again.",
            variant: "destructive",
          })
        }
      } else {
        toast({
          title: "No Hospital Found",
          description: "Please register your hospital first.",
          variant: "destructive",
        })
      }
      setIsLoading(false)
    }, 1000)
  }

  return (
    <Card className="mx-auto max-w-md">
      <CardHeader className="text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
          <Shield className="h-8 w-8 text-primary" />
        </div>
        <CardTitle className="text-2xl">Admin Login</CardTitle>
        <CardDescription>Enter your admin credentials to access the doctor dashboard</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="admin-id">Admin ID</Label>
          <Input
            id="admin-id"
            placeholder="Enter your Admin ID"
            value={adminId}
            onChange={(e) => setAdminId(e.target.value.toUpperCase())}
            className="font-mono"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="password">Password</Label>
          <div className="relative">
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
          </div>
        </div>
        <Button onClick={handleLogin} className="w-full" disabled={isLoading}>
          {isLoading ? "Signing In..." : "Sign In"}
        </Button>
        <div className="text-center text-sm text-muted-foreground">
          Don't have admin credentials? Contact your hospital administrator.
        </div>
      </CardContent>
    </Card>
  )
}
