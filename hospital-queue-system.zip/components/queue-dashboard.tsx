"use client"

import { Label } from "@/components/ui/label"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, Clock, CheckCircle, XCircle, QrCode, BarChart3, Calendar, LogOut, RefreshCw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Patient {
  id: string
  patientName: string
  doctorName: string
  position: number
  joinedAt: string
  estimatedTime: number
  status?: "waiting" | "in-consultation" | "completed" | "cancelled"
}

interface QueueDashboardProps {
  doctor: any
  onLogout: () => void
}

export function QueueDashboard({ doctor, onLogout }: QueueDashboardProps) {
  const { toast } = useToast()
  const [patients, setPatients] = useState<Patient[]>([])
  const [currentPatient, setCurrentPatient] = useState<Patient | null>(null)
  const [isRefreshing, setIsRefreshing] = useState(false)

  useEffect(() => {
    const loadQueueData = () => {
      try {
        let queueData = localStorage.getItem("hospitalQueue")

        // If no data found, try to initialize with empty array
        if (!queueData) {
          console.log("[v0] Admin dashboard - No queue data found, initializing empty array")
          localStorage.setItem("hospitalQueue", JSON.stringify([]))
          queueData = "[]"
        }

        console.log("[v0] Admin dashboard - Raw queue data:", queueData)
        console.log("[v0] Admin dashboard - Doctor name:", doctor.name)

        if (queueData) {
          const allPatients = JSON.parse(queueData) as Patient[]
          console.log("[v0] Admin dashboard - All patients:", allPatients)

          // Filter patients for this doctor and add status if not present
          const doctorPatients = allPatients
            .filter((p) => p.doctorName === doctor.name)
            .map((p) => ({ ...p, status: p.status || ("waiting" as const) }))

          console.log("[v0] Admin dashboard - Filtered doctor patients:", doctorPatients)
          console.log("[v0] Admin dashboard - Doctor patients count:", doctorPatients.length)
          setPatients(doctorPatients)
        } else {
          console.log("[v0] Admin dashboard - Still no queue data after initialization")
          setPatients([])
        }
      } catch (error) {
        console.error("[v0] Error loading queue data:", error)
        localStorage.setItem("hospitalQueue", JSON.stringify([]))
        setPatients([])
      }
    }

    loadQueueData()

    const handleStorageChange = () => {
      console.log("[v0] Storage change detected, reloading queue data")
      loadQueueData()
    }

    const handleQueueUpdate = (event: CustomEvent) => {
      console.log("[v0] Queue update event received in admin dashboard:", event.detail.queue)
      const allPatients = event.detail.queue as Patient[]
      const doctorPatients = allPatients
        .filter((p) => p.doctorName === doctor.name)
        .map((p) => ({ ...p, status: p.status || ("waiting" as const) }))
      setPatients(doctorPatients)
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("queueUpdated", handleQueueUpdate as EventListener)

    const interval = setInterval(loadQueueData, 1000)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("queueUpdated", handleQueueUpdate as EventListener)
      clearInterval(interval)
    }
  }, [doctor.name])

  const updateQueueData = (updatedPatients: Patient[]) => {
    try {
      const allQueueData = localStorage.getItem("hospitalQueue")
      let allPatients: Patient[] = []

      if (allQueueData) {
        allPatients = JSON.parse(allQueueData)
      }

      // Update patients for this doctor
      const otherDoctorPatients = allPatients.filter((p) => p.doctorName !== doctor.name)
      const newAllPatients = [...otherDoctorPatients, ...updatedPatients]

      localStorage.setItem("hospitalQueue", JSON.stringify(newAllPatients))
      setPatients(updatedPatients)

      window.dispatchEvent(
        new CustomEvent("queueUpdated", {
          detail: { queue: newAllPatients },
        }),
      )

      console.log("[v0] Updated queue data:", newAllPatients)
    } catch (error) {
      console.error("[v0] Error updating queue data:", error)
    }
  }

  const waitingPatients = patients.filter((p) => p.status === "waiting")
  const completedToday = patients.filter((p) => p.status === "completed").length
  const totalPatients = patients.length

  const callNextPatient = () => {
    if (waitingPatients.length === 0) {
      toast({
        title: "No Patients Waiting",
        description: "There are no patients in the queue.",
        variant: "destructive",
      })
      return
    }

    const nextPatient = waitingPatients[0]
    setCurrentPatient(nextPatient)

    const updatedPatients = patients.map((p) =>
      p.id === nextPatient.id ? { ...p, status: "in-consultation" as const } : p,
    )
    updateQueueData(updatedPatients)

    toast({
      title: "Patient Called",
      description: `${nextPatient.patientName} has been called for consultation.`,
    })
  }

  const completeConsultation = () => {
    if (!currentPatient) return

    const updatedPatients = patients.map((p) =>
      p.id === currentPatient.id ? { ...p, status: "completed" as const } : p,
    )
    updateQueueData(updatedPatients)
    setCurrentPatient(null)

    toast({
      title: "Consultation Completed",
      description: `${currentPatient.patientName}'s consultation has been marked as completed.`,
    })
  }

  const cancelPatient = (patientId: string) => {
    const patient = patients.find((p) => p.id === patientId)
    if (!patient) return

    const updatedPatients = patients.map((p) => (p.id === patientId ? { ...p, status: "cancelled" as const } : p))
    updateQueueData(updatedPatients)

    toast({
      title: "Patient Cancelled",
      description: `${patient.patientName} has been removed from the queue.`,
    })
  }

  const refreshQueue = () => {
    setIsRefreshing(true)
    try {
      const queueData = localStorage.getItem("hospitalQueue")
      if (queueData) {
        const allPatients = JSON.parse(queueData) as Patient[]
        const doctorPatients = allPatients
          .filter((p) => p.doctorName === doctor.name)
          .map((p) => ({ ...p, status: p.status || ("waiting" as const) }))
        setPatients(doctorPatients)
      }
    } catch (error) {
      console.error("[v0] Error refreshing queue:", error)
    }

    setTimeout(() => {
      setIsRefreshing(false)
      toast({
        title: "Queue Refreshed",
        description: "Patient queue has been updated.",
      })
    }, 1000)
  }

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  const getStatusColor = (status: Patient["status"]) => {
    switch (status) {
      case "waiting":
        return "bg-yellow-100 text-yellow-800"
      case "in-consultation":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Queue Dashboard</h1>
          <p className="text-muted-foreground">
            Dr. {doctor.name} - {doctor.specialization}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={refreshQueue} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Button variant="outline" size="sm" onClick={onLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Waiting</p>
                <p className="text-2xl font-bold">{waitingPatients.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-accent" />
              <div>
                <p className="text-sm text-muted-foreground">Avg Wait</p>
                <p className="text-2xl font-bold">
                  {waitingPatients.length > 0
                    ? Math.round(waitingPatients.reduce((acc, p) => acc + p.estimatedTime, 0) / waitingPatients.length)
                    : 0}
                  m
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="text-2xl font-bold">{completedToday}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-secondary" />
              <div>
                <p className="text-sm text-muted-foreground">Total Today</p>
                <p className="text-2xl font-bold">{totalPatients}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="queue" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="queue">Current Queue</TabsTrigger>
          <TabsTrigger value="consultation">Consultation</TabsTrigger>
          <TabsTrigger value="info">Doctor Info</TabsTrigger>
        </TabsList>

        <TabsContent value="queue" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Patient Queue
              </CardTitle>
              <CardDescription>Manage your patient queue and call the next patient</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {waitingPatients.length === 0 ? (
                <div className="text-center py-8">
                  <Users className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No patients waiting</p>
                </div>
              ) : (
                <>
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-muted-foreground">{waitingPatients.length} patient(s) waiting</p>
                    <Button onClick={callNextPatient}>Call Next Patient</Button>
                  </div>
                  <div className="space-y-3">
                    {waitingPatients.map((patient, index) => (
                      <div key={patient.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-medium">
                            {index + 1}
                          </div>
                          <Avatar>
                            <AvatarFallback>
                              {patient.patientName
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{patient.patientName}</p>
                            <p className="text-sm text-muted-foreground">Joined at {formatTime(patient.joinedAt)}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">~{patient.estimatedTime}m wait</Badge>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => cancelPatient(patient.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <XCircle className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="consultation" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Current Consultation
              </CardTitle>
              <CardDescription>Manage the patient currently in consultation</CardDescription>
            </CardHeader>
            <CardContent>
              {currentPatient ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback className="text-lg">
                        {currentPatient.patientName
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg">{currentPatient.patientName}</h3>
                      <p className="text-sm text-muted-foreground">
                        Consultation started at {formatTime(new Date().toISOString())}
                      </p>
                    </div>
                    <Badge className={getStatusColor(currentPatient.status)}>In Consultation</Badge>
                  </div>
                  <Button onClick={completeConsultation} className="w-full">
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Complete Consultation
                  </Button>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Clock className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No patient in consultation</p>
                  <p className="text-sm text-muted-foreground mt-2">Call the next patient from the queue to start</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="info" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <QrCode className="h-5 w-5" />
                  Doctor Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Name</Label>
                  <p className="text-sm">Dr. {doctor.name}</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Specialization</Label>
                  <p className="text-sm">{doctor.specialization}</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Admin ID</Label>
                  <p className="text-sm font-mono bg-muted px-2 py-1 rounded">{doctor.adminId}</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Entry Code</Label>
                  <p className="text-sm font-mono bg-muted px-2 py-1 rounded">{doctor.entryCode}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Today's Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <p className="text-2xl font-bold text-green-600">{completedToday}</p>
                    <p className="text-sm text-green-700">Completed</p>
                  </div>
                  <div className="text-center p-3 bg-yellow-50 rounded-lg">
                    <p className="text-2xl font-bold text-yellow-600">{waitingPatients.length}</p>
                    <p className="text-sm text-yellow-700">Waiting</p>
                  </div>
                </div>
                <div className="text-center p-3 bg-primary/10 rounded-lg">
                  <p className="text-2xl font-bold text-primary">{totalPatients}</p>
                  <p className="text-sm text-primary">Total Patients</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
