"use client"

import { useState, useEffect } from "react"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { HospitalRegistration } from "@/components/hospital-registration"
import { AdminLogin } from "@/components/admin-login"
import { PatientQueue } from "@/components/patient-queue"
import { QueueDashboard } from "@/components/queue-dashboard"
import { Building2, Users, QrCode } from "lucide-react"

export default function HomePage() {
  const [activeTab, setActiveTab] = useState("register")
  const [loggedInDoctor, setLoggedInDoctor] = useState<any>(null)

  useEffect(() => {
    const currentAdmin = localStorage.getItem("currentAdmin")
    if (currentAdmin) {
      setLoggedInDoctor(JSON.parse(currentAdmin))
      setActiveTab("admin")
    }
  }, [])

  const handleLoginSuccess = (doctor: any) => {
    setLoggedInDoctor(doctor)
  }

  const handleLogout = () => {
    localStorage.removeItem("currentAdmin")
    setLoggedInDoctor(null)
    setActiveTab("register")
  }

  if (loggedInDoctor) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b border-border bg-card">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                  <Building2 className="h-6 w-6" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">MediQueue</h1>
                  <p className="text-sm text-muted-foreground">Smart Hospital Queue Management</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="container mx-auto px-4 py-8">
          <QueueDashboard doctor={loggedInDoctor} onLogout={handleLogout} />
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <Building2 className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">MediQueue</h1>
                <p className="text-sm text-muted-foreground">Smart Hospital Queue Management</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mx-auto max-w-4xl">
          {/* Welcome Section */}
          <div className="mb-8 text-center">
            <h2 className="mb-4 text-3xl font-bold text-foreground">Welcome to MediQueue</h2>
            <p className="text-lg text-muted-foreground">
              Streamline your hospital operations with our intelligent queue management system
            </p>
          </div>

          {/* Feature Cards */}
          <div className="mb-8 grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader className="text-center">
                <Building2 className="mx-auto h-12 w-12 text-primary" />
                <CardTitle>Hospital Registration</CardTitle>
                <CardDescription>Register your hospital and set up doctor profiles with QR codes</CardDescription>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader className="text-center">
                <Users className="mx-auto h-12 w-12 text-primary" />
                <CardTitle>Queue Management</CardTitle>
                <CardDescription>Manage patient queues efficiently with real-time updates</CardDescription>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader className="text-center">
                <QrCode className="mx-auto h-12 w-12 text-primary" />
                <CardTitle>QR Code System</CardTitle>
                <CardDescription>Generate and manage QR codes for seamless patient check-ins</CardDescription>
              </CardHeader>
            </Card>
          </div>

          {/* Main Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="register">Hospital Registration</TabsTrigger>
              <TabsTrigger value="admin">Admin Login</TabsTrigger>
              <TabsTrigger value="queue">Join Queue</TabsTrigger>
            </TabsList>

            <TabsContent value="register" className="mt-6">
              <HospitalRegistration />
            </TabsContent>

            <TabsContent value="admin" className="mt-6">
              <AdminLogin onLoginSuccess={handleLoginSuccess} />
            </TabsContent>

            <TabsContent value="queue" className="mt-6">
              <PatientQueue />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
