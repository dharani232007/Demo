"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { QrCode, Download, Copy, Check } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface QRCodeGeneratorProps {
  doctorId: string
  doctorName: string
  entryCode: string
  qrCodeUrl: string
}

export function QRCodeGenerator({ doctorId, doctorName, entryCode, qrCodeUrl }: QRCodeGeneratorProps) {
  const { toast } = useToast()
  const [copied, setCopied] = useState(false)

  // Generate QR code URL using a public QR code API
  const qrCodeImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(
    qrCodeUrl,
  )}`

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      toast({
        title: "Copied!",
        description: "Entry code copied to clipboard.",
      })
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Could not copy to clipboard.",
        variant: "destructive",
      })
    }
  }

  const downloadQRCode = () => {
    const link = document.createElement("a")
    link.href = qrCodeImageUrl
    link.download = `qr-code-${doctorName.replace(/\s+/g, "-").toLowerCase()}.png`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: "QR Code Downloaded",
      description: `QR code for Dr. ${doctorName} has been downloaded.`,
    })
  }

  return (
    <Card>
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2">
          <QrCode className="h-5 w-5" />
          QR Code for Dr. {doctorName}
        </CardTitle>
        <CardDescription>Patients can scan this QR code to get the entry code</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* QR Code Display */}
        <div className="flex justify-center">
          <div className="rounded-lg border-2 border-dashed border-border p-4">
            <img
              src={qrCodeImageUrl || "/placeholder.svg"}
              alt={`QR Code for Dr. ${doctorName}`}
              className="h-48 w-48"
            />
          </div>
        </div>

        {/* Entry Code Display */}
        <div className="text-center space-y-2">
          <p className="text-sm text-muted-foreground">Entry Code</p>
          <div className="flex items-center justify-center gap-2">
            <Badge variant="outline" className="text-lg font-mono px-4 py-2">
              {entryCode}
            </Badge>
            <Button variant="ghost" size="sm" onClick={() => copyToClipboard(entryCode)} className="h-8 w-8 p-0">
              {copied ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button onClick={downloadQRCode} className="flex-1">
            <Download className="mr-2 h-4 w-4" />
            Download QR Code
          </Button>
          <Button variant="outline" onClick={() => copyToClipboard(qrCodeUrl)} className="flex-1">
            <Copy className="mr-2 h-4 w-4" />
            Copy Link
          </Button>
        </div>

        {/* Instructions */}
        <div className="rounded-lg bg-muted p-3 text-sm text-muted-foreground">
          <p className="font-medium mb-1">Instructions:</p>
          <ul className="space-y-1 text-xs">
            <li>• Display this QR code at your consultation room</li>
            <li>• Patients can scan to get your entry code</li>
            <li>• Entry code: {entryCode} can also be shared manually</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}
