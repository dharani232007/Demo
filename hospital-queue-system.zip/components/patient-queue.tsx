"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Users, Clock, QrCode, CheckCircle, User } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface QueueEntry {
  id: string
  patientName: string
  doctorName: string
  position: number
  joinedAt: Date
  estimatedTime: number
}

export function PatientQueue() {
  const { toast } = useToast()
  const [patientName, setPatientName] = useState("")
  const [entryCode, setEntryCode] = useState("")
  const [selectedDoctor, setSelectedDoctor] = useState("")
  const [isJoining, setIsJoining] = useState(false)
  const [isInQueue, setIsInQueue] = useState(false)
  const [currentQueueEntry, setCurrentQueueEntry] = useState<QueueEntry | null>(null)
  const [queueList, setQueueList] = useState<QueueEntry[]>([])

  // Get hospital data from localStorage
  const getHospitalData = () => {
    const data = localStorage.getItem("hospitalData")
    return data ? JSON.parse(data) : null
  }

  const getQueueData = () => {
    try {
      const data = localStorage.getItem("hospitalQueue")
      if (!data) {
        console.log("[v0] No queue data found, returning empty array")
        return []
      }
      const parsed = JSON.parse(data)
      console.log("[v0] Retrieved queue data:", parsed)
      return parsed
    } catch (error) {
      console.error("[v0] Error reading queue data:", error)
      return []
    }
  }

  const saveQueueData = (queue: QueueEntry[]) => {
    try {
      localStorage.setItem("hospitalQueue", JSON.stringify(queue))
      console.log("[v0] Successfully saved queue data:", queue)

      // Use a simple custom event instead for same-tab synchronization
      window.dispatchEvent(
        new CustomEvent("queueUpdated", {
          detail: { queue },
        }),
      )
    } catch (error) {
      console.error("[v0] Error saving queue data:", error)
    }
  }

  const hospitalData = getHospitalData()

  useEffect(() => {
    const existingQueue = getQueueData()
    console.log("[v0] Loading queue data:", existingQueue)
    setQueueList(existingQueue)

    // Check if current patient is already in queue
    if (patientName) {
      const patientInQueue = existingQueue.find(
        (entry: QueueEntry) => entry.patientName.toLowerCase() === patientName.toLowerCase(),
      )
      if (patientInQueue) {
        console.log("[v0] Found patient in queue:", patientInQueue)
        setCurrentQueueEntry(patientInQueue)
        setIsInQueue(true)
      }
    }

    const handleQueueUpdate = (event: CustomEvent) => {
      console.log("[v0] Queue update event received:", event.detail.queue)
      setQueueList(event.detail.queue)
    }

    window.addEventListener("queueUpdated", handleQueueUpdate as EventListener)

    return () => {
      window.removeEventListener("queueUpdated", handleQueueUpdate as EventListener)
    }
  }, [patientName]) // Add patientName as dependency to check when name changes

  const handleJoinQueue = () => {
    console.log("[v0] Attempting to join queue with:", { patientName, entryCode, selectedDoctor })

    if (!patientName || !entryCode || !selectedDoctor) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    if (!hospitalData) {
      toast({
        title: "No Hospital Found",
        description: "Please ensure the hospital is registered first to enable the queue system.",
        variant: "destructive",
      })
      return
    }

    // Verify entry code
    const doctor = hospitalData.doctors.find(
      (d: any) => d.name === selectedDoctor && d.entryCode === entryCode.toUpperCase(),
    )

    if (!doctor) {
      toast({
        title: "Invalid Entry Code",
        description: "The entry code doesn't match the selected doctor.",
        variant: "destructive",
      })
      return
    }

    setIsJoining(true)

    setTimeout(() => {
      const existingQueue = getQueueData()
      const doctorQueue = existingQueue.filter((entry: QueueEntry) => entry.doctorName === selectedDoctor)
      const position = doctorQueue.length + 1
      const estimatedTime = position * 15 // 15 minutes per patient

      const newQueueEntry: QueueEntry = {
        id: Date.now().toString(),
        patientName,
        doctorName: selectedDoctor,
        position,
        joinedAt: new Date(),
        estimatedTime,
      }

      console.log("[v0] Creating new queue entry:", newQueueEntry)

      const updatedQueue = [...existingQueue, newQueueEntry]
      saveQueueData(updatedQueue)
      setQueueList(updatedQueue)
      setCurrentQueueEntry(newQueueEntry)
      setIsInQueue(true)

      console.log("[v0] Queue state updated, isInQueue:", true)

      toast({
        title: "Successfully Joined Queue!",
        description: `You are number ${position} in Dr. ${doctor.name}'s queue.`,
      })

      setIsJoining(false)
    }, 1000)
  }

  const handleLeaveQueue = () => {
    if (currentQueueEntry) {
      const updatedQueue = queueList.filter((entry) => entry.id !== currentQueueEntry.id)
      saveQueueData(updatedQueue)
      setQueueList(updatedQueue)
      setCurrentQueueEntry(null)
      setIsInQueue(false)

      // Reset form
      setPatientName("")
      setEntryCode("")
      setSelectedDoctor("")

      toast({
        title: "Left Queue",
        description: "You have successfully left the queue.",
      })
    }
  }

  console.log("[v0] Current state:", { isInQueue, currentQueueEntry, queueList })

  if (!hospitalData) {
    return (
      <Card>
        <CardHeader className="text-center">
          <Users className="mx-auto h-12 w-12 text-muted-foreground" />
          <CardTitle>No Hospital Registered</CardTitle>
          <CardDescription>Please register a hospital first to enable the queue system.</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  if (isInQueue && currentQueueEntry) {
    const doctorQueue = queueList.filter((entry) => entry.doctorName === currentQueueEntry.doctorName)
    const currentPosition = doctorQueue.findIndex((entry) => entry.id === currentQueueEntry.id) + 1
    const estimatedWaitTime = (currentPosition - 1) * 15

    console.log("[v0] Rendering queue view for:", currentQueueEntry.patientName)

    return (
      <div className="space-y-6">
        {/* Current Queue Status */}
        <Card className="border-primary">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-primary">
              <CheckCircle className="h-5 w-5" />
              You're in the Queue!
            </CardTitle>
            <CardDescription>
              Dr. {currentQueueEntry.doctorName} - {hospitalData.name}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">{currentPosition}</div>
                <div className="text-sm text-muted-foreground">Your Position</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-secondary">{estimatedWaitTime}</div>
                <div className="text-sm text-muted-foreground">Minutes (Est.)</div>
              </div>
            </div>
            <Button onClick={handleLeaveQueue} variant="outline" className="w-full bg-transparent">
              Leave Queue
            </Button>
          </CardContent>
        </Card>

        {/* Queue List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Dr. {currentQueueEntry.doctorName}'s Queue
            </CardTitle>
            <CardDescription>Current patients waiting ({doctorQueue.length} total)</CardDescription>
          </CardHeader>
          <CardContent>
            {doctorQueue.length === 0 ? (
              <p className="text-center text-muted-foreground py-4">No patients in queue</p>
            ) : (
              <div className="space-y-3">
                {doctorQueue.map((entry, index) => (
                  <div
                    key={entry.id}
                    className={`flex items-center justify-between rounded-lg border p-3 ${
                      entry.id === currentQueueEntry.id ? "bg-primary/5 border-primary" : ""
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Badge variant={entry.id === currentQueueEntry.id ? "default" : "secondary"}>#{index + 1}</Badge>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4" />
                        <span className={entry.id === currentQueueEntry.id ? "font-medium" : ""}>
                          {entry.id === currentQueueEntry.id ? entry.patientName : `Patient ${index + 1}`}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      {index === 0 ? "Now" : `~${index * 15} min`}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Join Queue - {hospitalData.name}
          </CardTitle>
          <CardDescription>Enter your details and the doctor's entry code to join the queue</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="patient-name">Patient Name *</Label>
            <Input
              id="patient-name"
              placeholder="Enter your full name"
              value={patientName}
              onChange={(e) => setPatientName(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="doctor-select">Select Doctor *</Label>
            <Select value={selectedDoctor} onValueChange={setSelectedDoctor}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a doctor" />
              </SelectTrigger>
              <SelectContent>
                {hospitalData.doctors.map((doctor: any) => (
                  <SelectItem key={doctor.id} value={doctor.name}>
                    Dr. {doctor.name} - {doctor.specialization}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="entry-code">Entry Code *</Label>
            <Input
              id="entry-code"
              placeholder="Enter the 6-digit entry code"
              value={entryCode}
              onChange={(e) => setEntryCode(e.target.value.toUpperCase())}
              className="font-mono"
              maxLength={6}
            />
            <p className="text-sm text-muted-foreground">
              Get the entry code from the doctor's QR code or reception desk
            </p>
          </div>

          <Button onClick={handleJoinQueue} className="w-full" disabled={isJoining}>
            {isJoining ? "Joining Queue..." : "Join Queue"}
          </Button>
        </CardContent>
      </Card>

      {/* Available Doctors */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <QrCode className="h-5 w-5" />
            Available Doctors
          </CardTitle>
          <CardDescription>Current doctors available for consultation</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            {hospitalData.doctors.map((doctor: any) => {
              const doctorQueue = queueList.filter((entry) => entry.doctorName === doctor.name)
              return (
                <div key={doctor.id} className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <h3 className="font-medium">Dr. {doctor.name}</h3>
                    <p className="text-sm text-muted-foreground">{doctor.specialization}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">
                      <Users className="mr-1 h-3 w-3" />
                      {doctorQueue.length} waiting
                    </Badge>
                    <Badge variant="outline" className="font-mono">
                      {doctor.entryCode}
                    </Badge>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
