"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Plus, Trash2, Building2, User, QrCode, Key } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { QRCodeGenerator } from "@/components/qr-code-generator"

interface Doctor {
  id: string
  name: string
  specialization: string
  adminId: string
  password: string
  qrCode: string
  entryCode: string
}

interface HospitalData {
  name: string
  address: string
  phone: string
  email: string
  doctors: Doctor[]
}

export function HospitalRegistration() {
  const { toast } = useToast()
  const [step, setStep] = useState(1)
  const [hospitalData, setHospitalData] = useState<HospitalData>({
    name: "",
    address: "",
    phone: "",
    email: "",
    doctors: [],
  })

  const generateRandomId = () => Math.random().toString(36).substr(2, 8).toUpperCase()
  const generateQRCode = (doctorId: string) => `https://mediqueue.app/doctor/${doctorId}`
  const generateEntryCode = () => Math.random().toString(36).substr(2, 6).toUpperCase()

  const addDoctor = () => {
    const adminId = generateRandomId()
    const entryCode = generateEntryCode()
    const newDoctor: Doctor = {
      id: generateRandomId(),
      name: "",
      specialization: "",
      adminId,
      password: "",
      qrCode: generateQRCode(adminId),
      entryCode,
    }
    setHospitalData((prev) => ({
      ...prev,
      doctors: [...prev.doctors, newDoctor],
    }))
  }

  const removeDoctor = (id: string) => {
    setHospitalData((prev) => ({
      ...prev,
      doctors: prev.doctors.filter((doctor) => doctor.id !== id),
    }))
  }

  const updateDoctor = (id: string, field: keyof Doctor, value: string) => {
    setHospitalData((prev) => ({
      ...prev,
      doctors: prev.doctors.map((doctor) => (doctor.id === id ? { ...doctor, [field]: value } : doctor)),
    }))
  }

  const handleSubmit = () => {
    if (!hospitalData.name || !hospitalData.address || hospitalData.doctors.length === 0) {
      toast({
        title: "Incomplete Information",
        description: "Please fill in all hospital details and add at least one doctor.",
        variant: "destructive",
      })
      return
    }

    // Check if all doctors have required fields
    const incompleteDoctor = hospitalData.doctors.find(
      (doctor) => !doctor.name || !doctor.specialization || !doctor.password,
    )

    if (incompleteDoctor) {
      toast({
        title: "Incomplete Doctor Information",
        description: "Please fill in all doctor details including name, specialization, and password.",
        variant: "destructive",
      })
      return
    }

    // Save to localStorage (in real app, this would be sent to backend)
    localStorage.setItem("hospitalData", JSON.stringify(hospitalData))

    toast({
      title: "Registration Successful!",
      description: "Hospital has been registered successfully with all doctor profiles.",
    })

    setStep(3) // Show success step
  }

  if (step === 3) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <Building2 className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-2xl">Registration Complete!</CardTitle>
            <CardDescription>
              Your hospital has been successfully registered with {hospitalData.doctors.length} doctor(s)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="rounded-lg bg-muted p-4">
              <h3 className="font-semibold text-foreground mb-2">Hospital Details</h3>
              <p className="text-sm text-muted-foreground">
                <strong>Name:</strong> {hospitalData.name}
              </p>
              <p className="text-sm text-muted-foreground">
                <strong>Address:</strong> {hospitalData.address}
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold text-foreground">Doctor Credentials & QR Codes</h3>
              {hospitalData.doctors.map((doctor) => (
                <Card key={doctor.id} className="border-l-4 border-l-primary">
                  <CardContent className="pt-4">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{doctor.name}</span>
                          <Badge variant="secondary">{doctor.specialization}</Badge>
                        </div>
                        <div className="grid gap-1 text-muted-foreground text-sm">
                          <div className="flex items-center gap-2">
                            <Key className="h-4 w-4" />
                            <span>
                              Admin ID: <code className="bg-muted px-1 rounded">{doctor.adminId}</code>
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <QrCode className="h-4 w-4" />
                            <span>
                              Entry Code: <code className="bg-muted px-1 rounded">{doctor.entryCode}</code>
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex justify-center">
                        <QRCodeGenerator
                          doctorId={doctor.id}
                          doctorName={doctor.name}
                          entryCode={doctor.entryCode}
                          qrCodeUrl={doctor.qrCode}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Button
              onClick={() => {
                setStep(1)
                setHospitalData({ name: "", address: "", phone: "", email: "", doctors: [] })
              }}
              className="w-full"
            >
              Register Another Hospital
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Progress Indicator */}
      <div className="flex items-center justify-center space-x-4">
        <div
          className={`flex h-8 w-8 items-center justify-center rounded-full ${
            step >= 1 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
          }`}
        >
          1
        </div>
        <div className={`h-1 w-16 ${step >= 2 ? "bg-primary" : "bg-muted"}`} />
        <div
          className={`flex h-8 w-8 items-center justify-center rounded-full ${
            step >= 2 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
          }`}
        >
          2
        </div>
      </div>

      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Hospital Information
            </CardTitle>
            <CardDescription>Enter your hospital's basic information to get started</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="hospital-name">Hospital Name *</Label>
                <Input
                  id="hospital-name"
                  placeholder="Enter hospital name"
                  value={hospitalData.name}
                  onChange={(e) => setHospitalData((prev) => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hospital-phone">Phone Number</Label>
                <Input
                  id="hospital-phone"
                  placeholder="Enter phone number"
                  value={hospitalData.phone}
                  onChange={(e) => setHospitalData((prev) => ({ ...prev, phone: e.target.value }))}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="hospital-address">Address *</Label>
              <Textarea
                id="hospital-address"
                placeholder="Enter complete hospital address"
                value={hospitalData.address}
                onChange={(e) => setHospitalData((prev) => ({ ...prev, address: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="hospital-email">Email Address</Label>
              <Input
                id="hospital-email"
                type="email"
                placeholder="Enter email address"
                value={hospitalData.email}
                onChange={(e) => setHospitalData((prev) => ({ ...prev, email: e.target.value }))}
              />
            </div>
            <Button
              onClick={() => setStep(2)}
              className="w-full"
              disabled={!hospitalData.name || !hospitalData.address}
            >
              Continue to Doctor Setup
            </Button>
          </CardContent>
        </Card>
      )}

      {step === 2 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Doctor Setup
            </CardTitle>
            <CardDescription>Add doctors and configure their admin credentials</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {hospitalData.doctors.map((doctor, index) => (
              <Card key={doctor.id} className="border-dashed">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Doctor {index + 1}</CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeDoctor(doctor.id)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Doctor Name *</Label>
                      <Input
                        placeholder="Enter doctor name"
                        value={doctor.name}
                        onChange={(e) => updateDoctor(doctor.id, "name", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Specialization *</Label>
                      <Select
                        value={doctor.specialization}
                        onValueChange={(value) => updateDoctor(doctor.id, "specialization", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select specialization" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cardiology">Cardiology</SelectItem>
                          <SelectItem value="dermatology">Dermatology</SelectItem>
                          <SelectItem value="neurology">Neurology</SelectItem>
                          <SelectItem value="orthopedics">Orthopedics</SelectItem>
                          <SelectItem value="pediatrics">Pediatrics</SelectItem>
                          <SelectItem value="general">General Medicine</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Admin Password *</Label>
                    <Input
                      type="password"
                      placeholder="Set admin password"
                      value={doctor.password}
                      onChange={(e) => updateDoctor(doctor.id, "password", e.target.value)}
                    />
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="rounded-lg bg-muted p-3">
                      <Label className="text-sm font-medium">Admin ID</Label>
                      <p className="text-sm font-mono text-muted-foreground">{doctor.adminId}</p>
                    </div>
                    <div className="rounded-lg bg-muted p-3">
                      <Label className="text-sm font-medium">Entry Code</Label>
                      <p className="text-sm font-mono text-muted-foreground">{doctor.entryCode}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            <Button variant="outline" onClick={addDoctor} className="w-full border-dashed bg-transparent">
              <Plus className="mr-2 h-4 w-4" />
              Add Doctor
            </Button>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(1)} className="flex-1">
                Back
              </Button>
              <Button onClick={handleSubmit} className="flex-1">
                Complete Registration
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
